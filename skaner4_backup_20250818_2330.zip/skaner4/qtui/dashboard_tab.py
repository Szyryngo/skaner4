"""
dashboard_tab.py
Re-export klasy DashboardTab z qt_dashboard.py.
"""
from .qt_dashboard import DashboardTab

